---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
<!-- What is the problem you would like to solve? -->

**Describe the solution you'd like**
<!-- A clear and concise description of what you want to happen.-->

**Describe alternatives you've considered**
<!-- are there any other ways this problem could be solved? -->

**Additional context**
<!-- Add any other context or screenshots about the feature request here.-->
